---
type : "tags"
layout : "notes"
title: "Notes"
subtitle : "Your musings or reading notes"
---
