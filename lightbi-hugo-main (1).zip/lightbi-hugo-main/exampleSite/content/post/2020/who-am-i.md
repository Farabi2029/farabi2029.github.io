---
title: Who am I ?!
date: 2020-01-01
tags: ["stoicism"]
image : "/img/posts/img-0.jpg"
Description  : "Who am I ?! This is the most asked question in my life. Yet no clear answer has yet been found..."
---
Who am I ?! This is the most asked question in my life. Yet no clear answer has yet been found.

As a child, the answer to this question was simple. Say my name to the question of who. Aha ..! Simple and beautiful. In that answer, parents and siblings in adolescence. I thought to myself that the answer was too clear. 

When I started asking myself this question at a young age when I was beginning to recognize many things, I began to feel that the answer was becoming less clear. Who am I ?! If you ask me who I am. Anyone else. Still no answer to the question. Who am I?

Seek, that is the way to find the answer. Knock, and it shall be opened unto you !! The investigation has begun. 

There is no doubt where to start. From me. I began to search the bottom of my heart in the silence. From there the search went on to the printed books. Couldn't figure it out from there. No suitable gurus could be found to answer this question.

The search continued, and the only sound in my heart was to go ahead. The answer is nowhere to be found. So I'm still looking around, and the answer to my question is hidden somewhere.

I do not know, some questions take time to answer. The meaning of a single word question is getting bigger and bigger. Who am I ?! What is my identity ?! What are my missions ?! Can I know the light of the answers ?!

Those who ask the same questions go up the steps of consciousness and seem to be enlightened and insane. What will I become at the end of this question? !! Buddha or mad !! Anyone should have a small smile left at the end. The smile of recognition.

Who am I, let the question continue. 
<!--Photo by Robert Katzki on Unsplash-->
